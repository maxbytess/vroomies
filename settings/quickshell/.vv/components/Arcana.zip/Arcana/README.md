# Arcana

vroomies dashboard'u (floating). Aphotic-Hypr "spine" tasarimi + senin parcalarin.

| Dosya | Gorev |
|---|---|
| Sway.qml | Pencere, sekmeler, durum/surecler, bildirim sunucusu, IPC |
| HomeTab.qml | 12x6 bento izgarasi |
| MeTab.qml | ( Me ): profil, pil, kilit/ss/guc, ses-parlaklik, bildirimler |
| CynaCard.qml | Cyna medya oynaticisi (tile icinde) |
| WifiTab / BluetoothTab / AITab | Eski panellerin gomulu halleri |
| DashCard / Ring / Spline | Tile ve grafik bilesenleri |
